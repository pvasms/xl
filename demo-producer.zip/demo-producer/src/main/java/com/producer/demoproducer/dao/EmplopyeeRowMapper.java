package com.producer.demoproducer.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.producer.demoproducer.model.Employee;

public class EmplopyeeRowMapper implements RowMapper {

	@Override
	public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		Employee employee= new Employee(rs.getString("id"), rs.getString("name"), rs.getString("email"), rs.getString("salary"));
		return employee;
	}

}
