package com.producer.demoproducer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.producer.demoproducer.dao.EmployeeDao;
import com.producer.demoproducer.dao.EmployeeDaoImpl;
import com.producer.demoproducer.model.Employee;

@SpringBootApplication
public class DemoProducerApplication {
	
	@Autowired
	EmployeeDao employeeDao;
	
	public static void main(String[] args) {
		SpringApplication.run(DemoProducerApplication.class, args);
	}

	/*
	 * 
	 * @Override public void run(String... args) throws Exception {
	 * 
	 * createEmployee(); }
	 * 
	 * private void createEmployee() { Employee e= new Employee("10", "deepak",
	 * "deepak@gmail.com", "30000");
	 * 
	 * String result =employeeDao.createEmployee(e); System.out.println(result); }
	 */
}
