package com.producer.demoproducer.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.producer.demoproducer.model.Employee;

@Repository
public class EmployeeDaoImpl implements EmployeeDao{

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Employee> getAllEmployees() {
		
	String sql="SELECT * FROM EMPLOYEE";
		
	List<Employee> employees=null; 
	       
	//new EmplopyeeRowMapper()=(List<Employee>) jdbcTemplate.queryForObject(sql, new EmplopyeeRowMapper());
	
	    employees=jdbcTemplate.query(sql, new EmplopyeeRowMapper());
		return employees;
	}

	@Override
	public Employee getEmployeeById() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee updateEmployee() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee deleteEmployeeById() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String createEmployee(Employee emp) {

		String sql="INSERT INTO employee(id, name, email, salary) VALUES (?,?,?,?)";
		
		int resutlt=jdbcTemplate.update(sql, emp.getId(),emp.getName(),emp.getEmail(),emp.getSalary());
		
		if(resutlt==1) {
			return "Employee created succsessfully";
		
	}
		else {
		return "Employee creation failled";
		}
	}
	

}
