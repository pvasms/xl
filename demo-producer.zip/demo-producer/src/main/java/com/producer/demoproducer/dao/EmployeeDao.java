package com.producer.demoproducer.dao;

import java.util.List;

import com.producer.demoproducer.model.Employee;

public interface EmployeeDao {
	
	public List<Employee> getAllEmployees();
	public Employee getEmployeeById();
	public Employee updateEmployee();
	public Employee deleteEmployeeById();
	public String createEmployee(Employee emp);
	
	
	
}
