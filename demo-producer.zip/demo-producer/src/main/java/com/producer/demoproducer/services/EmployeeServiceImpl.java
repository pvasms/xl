package com.producer.demoproducer.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.producer.demoproducer.dao.EmployeeDao;
import com.producer.demoproducer.model.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeServices{

	@Autowired
	EmployeeDao employeeDao;
	
	@Override
	public List<Employee> getAllEmployees() {
		return employeeDao.getAllEmployees();
	}

	@Override
	public Employee getEmployeeById() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee updateEmployee() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee deleteEmployeeById() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String createEmployee(Employee emp) {
		
		return employeeDao.createEmployee(emp);
	}

}
